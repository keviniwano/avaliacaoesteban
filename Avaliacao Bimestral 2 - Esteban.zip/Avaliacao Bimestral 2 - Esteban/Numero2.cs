using System;  

class Program  
{  
    static void Main()  
    {  
        Console.WriteLine("Olá! Vamos calcular a quantidade de dias entre duas datas.");  
        
        Console.Write("Por favor, insira a primeira data (formato: dd/mm/yyyy): ");  
        string data1Input = Console.ReadLine();   
        
        Console.Write("Agora, insira a segunda data (formato: dd/mm/yyyy): ");  
        string data2Input = Console.ReadLine();   

        DateTime data1;  
        DateTime data2;  

        if (DateTime.TryParseExact(data1Input, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out data1) &&  
            DateTime.TryParseExact(data2Input, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out data2))  
        {  
            TimeSpan diferenca = data2 - data1;  
            int diasEntreDatas = Math.Abs(diferenca.Days);   

            Console.WriteLine($"Entre {data1:dd/MM/yyyy} e {data2:dd/MM/yyyy}, há um total de {diasEntreDatas} dias.");  
        }  
        else  
        {  
            Console.WriteLine("Parece que houve um erro. Verifique se as datas estão no formato correto (dd/mm/yyyy) e tente novamente.");  
        }  
    }  
}