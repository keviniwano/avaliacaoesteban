using System;  

class Program  
{  
    static void Main()  
    {  
        Console.WriteLine("Digite uma frase: ");  
        string frase = Console.ReadLine();  

        int numeroDePalavras = ContarPalavras(frase);  

        Console.WriteLine($"A frase contém {numeroDePalavras} palavra(s).");  
    }  

    static int ContarPalavras(string frase)  
    {  
        if (string.IsNullOrWhiteSpace(frase))  
        {  
            return 0; 
        }  

        string[] palavras = frase.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);  
        
        return palavras.Length;  
    }  
}